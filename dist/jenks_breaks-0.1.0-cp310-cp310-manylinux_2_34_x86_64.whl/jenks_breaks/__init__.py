from .jenks_breaks import *

__doc__ = jenks_breaks.__doc__
if hasattr(jenks_breaks, "__all__"):
    __all__ = jenks_breaks.__all__